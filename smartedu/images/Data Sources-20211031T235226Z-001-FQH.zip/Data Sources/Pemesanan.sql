-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 29, 2021 at 03:43 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 7.3.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `Pemesanan`
--
CREATE DATABASE IF NOT EXISTS `Pemesanan` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `Pemesanan`;

-- --------------------------------------------------------

--
-- Table structure for table `checkouts`
--

CREATE TABLE `checkouts` (
  `orderNo` int(11) NOT NULL,
  `productCode` varchar(15) NOT NULL,
  `qtyOrdered` int(11) NOT NULL,
  `priceEach` decimal(10,2) NOT NULL,
  `checkoutNo` smallint(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `checkouts`
--

INSERT INTO `checkouts` (`orderNo`, `productCode`, `qtyOrdered`, `priceEach`, `checkoutNo`) VALUES
(280272225, '06 fl', 9151, '2758317.32', 840),
(139932285, '02 dx', 11303, '6784406.64', 852),
(446585897, '11 ai', 89432, '810501.20', 1978),
(25693539, '00 vd', 30058, '9239295.70', 2083),
(548424402, '12 bi', 10657, '2127438.41', 3274),
(187547294, '05 xl', 98612, '1356118.31', 3553),
(433194542, '10 nf', 34875, '8133395.27', 3619),
(156538199, '04 te', 51130, '3027317.35', 4847),
(81189539, '01 wh', 45448, '694263.29', 5313),
(381066528, '10 ba', 89436, '9865000.30', 5419),
(48378529, '01 sk', 34632, '8970413.05', 5657),
(290662941, '06 is', 7433, '4436968.50', 6789),
(17579462, '00 gn', 47314, '3461084.92', 6860),
(558135405, '12 ja', 11948, '7590071.63', 6975),
(167907594, '05 lp', 5260, '393320.62', 7037),
(29699998, '01 gz', 87117, '5302062.41', 7320),
(370930929, '09 bt', 56866, '1722963.87', 7645),
(471297491, '11 yx', 90159, '9109467.65', 7743),
(24115540, '00 is', 87006, '6579504.43', 7795),
(313055252, '08 dg', 1921, '3412448.01', 7843),
(62089116, '01 sq', 22489, '7891802.41', 7981),
(349577766, '08 fi', 18516, '5392394.74', 8141),
(458385570, '11 rf', 77328, '758065.38', 8493),
(302443970, '06 lu', 77134, '5717052.70', 8791),
(86499996, '01 yz', 85032, '7110507.49', 9198);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `orderNo` int(11) NOT NULL,
  `orderDate` date NOT NULL,
  `requiredDate` date NOT NULL,
  `shippedDate` date DEFAULT NULL,
  `checkNo` varchar(50) NOT NULL,
  `status` varchar(15) NOT NULL,
  `comments` text DEFAULT NULL,
  `customerNo` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`orderNo`, `orderDate`, `requiredDate`, `shippedDate`, `checkNo`, `status`, `comments`, `customerNo`) VALUES
(17579462, '1981-11-29', '2018-06-11', '1972-04-08', '4716714700156', ' send', '', 162753584),
(24115540, '2010-06-17', '2018-12-28', '1975-02-23', '340886520106145', ' packaging', '', 321122186),
(25693539, '1989-05-16', '2018-09-24', '2016-07-01', '4929139095038', 'in progress', 'In ducimus tenetur consequatur occaecati soluta.', 185973191),
(29699998, '2011-08-01', '2018-12-14', '1984-10-07', '5408744648017916', ' cancel', 'Ut vitae quis soluta.', 217708340),
(48378529, '2014-10-19', '2019-11-04', '2006-09-30', '5415766690456816', ' done', '', 269232655),
(62089116, '2017-06-05', '2016-01-15', '1975-04-03', '5264077225319698', 'in progress', '', 205556914),
(81189539, '1970-11-28', '2011-06-22', '2018-01-23', '5311896557321113', ' cancel', '', 212209990),
(86499996, '1980-10-07', '2019-10-06', '1977-11-30', '5413402574202417', ' send', 'Et sapiente molestiae velit id exercitationem.', 262812785),
(139932285, '1986-01-17', '2020-11-19', '0000-00-00', '4024007183839861', ' packaging', '', 381285376),
(156538199, '1991-12-20', '2015-07-04', '1974-01-22', '342720222538563', ' send', '', 343063458),
(167907594, '2016-04-02', '2018-07-05', '1988-05-21', '344628991650563', 'in progress', '', 345411627),
(187547294, '1978-10-15', '2018-07-31', '2001-07-16', '4556415261434', 'in progress', '', 158490238),
(280272225, '1988-11-14', '2017-08-31', '2012-11-25', '370397520407868', ' shipped', '', 45621940),
(290662941, '2002-03-27', '2016-05-23', '1979-01-20', '370875244615173', ' done', 'Occaecati aspernatur quod maxime quibusdam.', 354157549),
(302443970, '1972-10-27', '2019-01-29', '0000-00-00', '372190429565222', ' done', 'Sed reprehenderit nihil hic officiis.', 360523504),
(313055252, '2002-05-14', '2018-02-06', '1977-03-01', '4539086504068', ' done', 'Doloribus officiis omnis dicta ullam maiores qui sapiente.', 157533125),
(349577766, '1991-11-09', '2019-05-09', '0000-00-00', '4387192216112', ' send', 'Quasi sit quod sed impedit.', 145447032),
(370930929, '2001-03-03', '2019-08-23', '1994-11-16', '6011584196555068', ' shipped', '', 313746280),
(381066528, '1993-09-02', '2012-07-15', '0000-00-00', '4716966722069742', ' cancel', '', 181617039),
(433194542, '1987-05-16', '2014-05-06', '2020-08-25', '4929628618905435', ' cancel', '', 191973770),
(446585897, '1970-01-29', '2020-03-16', '1996-05-05', '5533433836338098', ' done', 'Ducimus odit perspiciatis consectetur.', 289826069),
(458385570, '1970-12-06', '2017-11-10', '2018-07-01', '344628991650563', ' shipped', 'Ut et rerum perspiciatis est dignissimos.', 35673676),
(471297491, '1993-06-11', '2014-05-03', '2017-08-18', '5485924424443921', ' send', '', 279403398),
(548424402, '1982-08-20', '2012-07-29', '0000-00-00', '375489487067508', ' done', 'Natus magnam dignissimos sapiente voluptate.', 364771437),
(558135405, '1973-10-13', '2016-10-16', '1987-06-28', '4024007183839861', ' done', 'Facilis adipisci quia et recusandae.', 120126610),
(637347985, '2013-06-26', '2015-01-16', '1986-02-22', '370875244615173', ' cancel', 'Aut quod blanditiis ut sed.', 59874864),
(698026071, '2014-06-01', '2019-08-20', '2003-03-03', '4024007188336658', ' shipped', 'Quia eum veritatis rerum nisi dolores.', 395106995),
(716475046, '2001-10-23', '2018-02-02', '0000-00-00', '340886520106145', ' shipped', 'Enim excepturi ut et at.', 23912919),
(723784875, '2002-09-14', '2011-05-17', '0000-00-00', '6011355926981242', ' packaging', '', 311583183),
(758084396, '1993-12-16', '2017-12-31', '1980-10-25', '370397520407868', ' send', 'Necessitatibus sequi ut dolor quis accusamus inventore.', 348373666),
(769155265, '2009-02-04', '2018-12-29', '2009-09-06', '4532462907644', ' done', 'Optio tempora sed voluptatem error totam.', 147373431),
(782545135, '1973-10-26', '2015-08-08', '1998-06-20', '4024007188336658', ' packaging', 'Omnis quibusdam vitae ullam aliquid quisquam voluptas eum.', 134638347),
(801957319, '2009-01-02', '2021-03-29', '0000-00-00', '5147926461203079', ' cancel', '', 204106093),
(826423613, '1983-01-12', '2014-06-01', '1972-11-14', '5348181605752673', ' cancel', 'Qui natus eaque laudantium quae repellendus sint.', 212843535),
(899476744, '1972-05-05', '2012-06-16', '0000-00-00', '375489487067508', ' packaging', 'Doloremque ratione sint ratione sit iure.', 92032905),
(912017552, '1998-05-29', '2020-07-13', '1985-05-17', '4024007121842657', 'in progress', 'Eligendi quod ex nostrum magni aut.', 110668732),
(922904158, '1970-12-19', '2017-11-07', '0000-00-00', '4929297156588', ' send', '', 188210246),
(948370350, '1982-01-18', '2011-09-26', '2005-12-08', '372190429565222', ' packaging', 'Aliquid consectetur quia nulla aut quia labore.', 84571217),
(973344378, '1986-07-09', '2013-05-21', '2012-01-23', '342720222538563', ' done', 'Dolorum facilis eius aut distinctio.', 30021024),
(990350417, '1998-12-03', '2018-11-27', '0000-00-00', '4024007121842657', ' cancel', '', 366007637);

-- --------------------------------------------------------

--
-- Table structure for table `productlines`
--

CREATE TABLE `productlines` (
  `productCode` varchar(15) NOT NULL,
  `textDescription` text DEFAULT NULL,
  `htmlDescription` mediumtext DEFAULT NULL,
  `image` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `productlines`
--

INSERT INTO `productlines` (`productCode`, `textDescription`, `htmlDescription`, `image`) VALUES
('00 gn', 'Voluptatum quia adipisci voluptatibus omnis deserunt ut aperiam.', '', ''),
('00 is', '', 'Saepe assumenda est quibusdam perspiciatis omnis unde. Veritatis temporibus itaque temporibus reprehenderit ut quasi odio. Aliquam voluptate iure voluptatem deleniti voluptas hic.', ''),
('00 vd', '', 'Est culpa ea et non omnis eius. Voluptas optio libero pariatur nostrum sit sit. Et perferendis eaque esse deleniti corporis voluptas voluptatibus. Voluptate dicta minima quod sit excepturi.', 'http://lorempixel.com/200/300/technics/'),
('01 gz', 'Debitis omnis rerum impedit in odit quae quia.', 'Laudantium debitis aperiam quia dolor enim esse voluptatem. Excepturi animi optio asperiores numquam enim dicta id. Architecto ratione autem est eligendi dolores veniam nostrum.', ''),
('01 sk', '', 'Ut ut inventore dolor qui dolores aut quia amet. Quia dicta non explicabo corrupti. Aut tempore at repellat dignissimos. Cum esse adipisci vel explicabo.', 'http://lorempixel.com/200/300/technics/'),
('01 sq', 'Alias reiciendis at sed voluptas.', '', ''),
('01 wh', 'Et eligendi odio incidunt temporibus omnis.', '', 'http://lorempixel.com/200/300/technics/'),
('01 yz', 'A suscipit aut sit modi impedit odio.', 'Veritatis quo ducimus non corporis accusantium. Quasi occaecati nemo id asperiores reprehenderit tempore. Facere velit aperiam occaecati magni.', ''),
('02 dx', 'Voluptatum asperiores fuga impedit illo possimus voluptatem.', '', ''),
('04 te', 'Facere sit illo eaque quidem eius minima.', '', ''),
('05 lp', 'Dolores doloremque architecto delectus architecto incidunt quis recusandae.', 'Est sed voluptatem iusto eos. Unde dolor cum laudantium quia in et ullam. Deleniti voluptatum illum ut voluptate ad sint deserunt. Neque et in et et numquam aspernatur sed.', 'http://lorempixel.com/200/300/technics/'),
('05 xl', '', 'Maiores magni eligendi voluptas voluptatibus a debitis fugiat illo. Qui qui aliquam expedita quasi et omnis. Velit molestiae aut voluptatum velit consectetur eos. Dolorum aliquid nam officia totam quo quod et. Qui qui sit sed.', 'http://lorempixel.com/200/300/technics/'),
('06 fl', '', 'Qui tempora natus sapiente aut. Et vero et earum alias illo. Quas porro iusto tempora quidem dolores.', 'http://lorempixel.com/200/300/technics/'),
('06 is', 'Dolor sunt debitis dignissimos optio consequatur odio ipsum.', '', 'http://lorempixel.com/200/300/technics/'),
('06 lu', 'Aut molestiae facere expedita doloribus atque.', '', ''),
('08 dg', '', 'Et tenetur consequatur quas laborum est. A laudantium voluptas dolore cumque nemo. Perspiciatis perspiciatis doloremque possimus accusantium alias vero.', 'http://lorempixel.com/200/300/technics/'),
('08 fi', '', '', ''),
('09 bt', 'Dicta voluptas dolorem et totam nam eius.', 'Non aut possimus nihil rerum esse. Corporis occaecati quam nobis adipisci. Magni tempore eum aut rerum voluptatibus voluptatum. Illum voluptas amet et repellat voluptatem nisi.', ''),
('10 ba', 'Modi autem et dolores maiores necessitatibus iure saepe.', '', ''),
('10 nf', 'Voluptatibus ipsa explicabo officia modi numquam.', 'Facere reiciendis quo voluptas rerum qui a eligendi. Rerum nihil quas sed dolorum id aliquam magni. Eum quibusdam tempore rerum consequatur repellat voluptatum.', ''),
('11 ai', '', 'Beatae corporis blanditiis est et delectus est. Itaque tenetur ipsum consequatur consequatur doloribus velit maxime. Ipsam ratione nam sunt impedit aliquam quia quasi. Explicabo sit ipsam hic molestiae dolore autem iusto.', ''),
('11 rf', 'Beatae laudantium et rerum debitis.', 'Rerum natus nam incidunt accusamus reiciendis voluptatem nostrum. Ut voluptates vitae quidem vel commodi qui dignissimos rem. Quos est suscipit sit ipsa vel.', 'http://lorempixel.com/200/300/technics/'),
('11 yx', 'Perspiciatis eum alias ipsum repudiandae facere molestiae.', 'Doloremque velit voluptatum illo eligendi vitae. Tempora voluptas et aperiam. Consequuntur ut quos ab ullam non.', 'http://lorempixel.com/200/300/technics/'),
('12 bi', 'Sed debitis quis accusamus et aut nihil.', 'Numquam ut quod voluptatem libero non. Cupiditate sed vitae occaecati hic minus quis. Laboriosam asperiores quos quod est deserunt saepe. Dolor qui fuga laboriosam architecto quas sed.', ''),
('12 ja', '', '', 'http://lorempixel.com/200/300/technics/'),
('12 ju', 'Nesciunt odit aut consequatur voluptas repellat ut.', '', ''),
('12 zq', 'Odio ad vel qui in.', 'Error sunt molestias minima placeat quia quia. Optio est molestias praesentium cum sit quo ullam consequuntur.', ''),
('13 qa', 'Quibusdam officiis unde sint ratione id quam.', '', ''),
('13 yc', 'Quia veritatis occaecati vel cumque qui qui.', '', 'http://lorempixel.com/200/300/technics/'),
('14 ea', 'Eos tenetur voluptatem debitis.', '', ''),
('14 ec', 'Quasi incidunt distinctio dignissimos doloremque itaque.', '', ''),
('15 sz', '', 'Eos incidunt quia quaerat harum tempore corporis. Sit et amet quae. Aut minima nostrum qui sunt et temporibus consequuntur. Sed consequuntur nisi aliquid.', 'http://lorempixel.com/200/300/technics/'),
('16 zl', '', '', ''),
('17 ak', 'Rerum voluptatem velit magni quis doloremque nihil.', '', 'http://lorempixel.com/200/300/technics/'),
('17 kw', '', 'Molestias aut esse quia dolorem. Maxime labore quos cumque a mollitia. Ut qui maiores quia iste. Necessitatibus in repellendus ipsum.', 'http://lorempixel.com/200/300/technics/');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `productCode` varchar(15) NOT NULL,
  `prodName` varchar(70) NOT NULL,
  `prodDescription` text NOT NULL,
  `qtyInStock` smallint(6) NOT NULL,
  `buyPrice` int(10) NOT NULL,
  `officeCode` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`productCode`, `prodName`, `prodDescription`, `qtyInStock`, `buyPrice`, `officeCode`) VALUES
('00 gn', 'Milk', 'Lizard, Bill, was in livery: otherwise, judging by his garden.\"\' Alice did not like to be seen: she found to be told so. \'It\'s really dreadful,\' she muttered to herself, as usual. I wonder who will.', 10714, 1750236, 'krpp'),
('00 is', 'Shawl', 'Mock Turtle: \'nine the next, and so on.\' \'What a curious appearance in the sea, \'and in that ridiculous fashion.\' And he added in a furious passion, and went on in a very interesting dance to.', 32767, 7140700, 'hmfc'),
('00 vd', 'Barbel', 'Cat again, sitting on the trumpet, and called out, \'First witness!\' The first witness was the White Rabbit. She was close behind us, and he\'s treading on my tail. See how eagerly the lobsters to the.', 20741, 6732661, 'bhfe'),
('01 gz', 'Barbel', 'Alice in a hurry that she was now about two feet high: even then she walked sadly down the chimney, has he?\' said Alice loudly. \'The idea of having the sentence first!\' \'Hold your tongue, Ma!\' said.', 32767, 3830162, 'krpp'),
('01 sk', 'Pasta', 'THIS size: why, I should say \"With what porpoise?\"\' \'Don\'t you mean by that?\' said the Hatter: \'I\'m on the hearth and grinning from ear to ear. \'Please would you like the wind, and was going off.', 32767, 8389927, 'qpqe'),
('01 sq', 'Clothes', 'Majesty!\' the soldiers shouted in reply. \'Idiot!\' said the King and Queen of Hearts, and I shall be a person of authority over Alice. \'Stand up and ran off, thinking while she remembered how small.', 8473, 4225785, 'rosj'),
('01 wh', 'Shawl', 'Alice, looking down with one eye; \'I seem to put down her flamingo, and began by taking the little door into that beautiful garden--how IS that to be no use in saying anything more till the Pigeon.', 32767, 3630423, 'bhfe'),
('01 yz', 'Dummbell', 'Rabbit angrily. \'Here! Come and help me out of its mouth, and addressed her in a very fine day!\' said a whiting to a day-school, too,\' said Alice; \'that\'s not at all fairly,\' Alice began, in a.', 32767, 1115540, 'tqiw'),
('02 dx', 'Milk', 'CAN all that green stuff be?\' said Alice. \'I\'m a--I\'m a--\' \'Well! WHAT are you?\' And then a row of lodging houses, and behind them a railway station.) However, she soon made out what it meant till.', 32767, 2003782, 'qpqe'),
('04 te', 'Mug', 'King eagerly, and he wasn\'t going to remark myself.\' \'Have you guessed the riddle yet?\' the Hatter were having tea at it: a Dormouse was sitting next to no toys to play with, and oh! ever so many.', 32767, 8519037, 'ymkk'),
('05 lp', 'Bath Tub', 'Gryphon whispered in a rather offended tone, \'so I can\'t remember,\' said the Duchess, \'chop off her unfortunate guests to execution--once more the pig-baby was sneezing and howling alternately.', 32767, 6633402, 'pkrr'),
('05 xl', 'Chair', 'Queen shrieked out. \'Behead that Dormouse! Turn that Dormouse out of a muchness\"--did you ever saw. How she longed to get rather sleepy, and went down on the hearth and grinning from ear to ear..', 21939, 8792880, 'lgxf'),
('06 fl', 'Burger', 'King, going up to Alice, and she drew herself up on to her full size by this very sudden change, but very glad to do anything but sit with its wings. \'Serpent!\' screamed the Pigeon. \'I can tell you.', 14434, 2660145, 'slnz'),
('06 is', 'Fan', 'Duchess said in a sulky tone, as it went, as if she were saying lessons, and began bowing to the jury, and the bright eager eyes were looking over their shoulders, that all the arches are gone from.', 32767, 2460554, 'rycr'),
('06 lu', 'Barbel', 'OURS they had at the Lizard in head downwards, and the m--\' But here, to Alice\'s great surprise, the Duchess\'s knee, while plates and dishes crashed around it--once more the pig-baby was sneezing on.', 22766, 8518309, 'krpp'),
('08 dg', 'Pasta', 'Queen said to Alice. \'Only a thimble,\' said Alice as he fumbled over the wig, (look at the top of his great wig.\' The judge, by the officers of the soldiers had to sing this:-- \'Beautiful Soup, so.', 25678, 8013641, 'pkrr'),
('08 fi', 'Fried Chicken', 'Alice. \'That\'s the reason and all of you, and must know better\'; and this time she had hoped) a fan and gloves--that is, if I fell off the subjects on his knee, and the bright eager eyes were nearly.', 32767, 5709663, 'dsjt'),
('09 bt', 'Table', 'COULD! I\'m sure _I_ shan\'t be able! I shall never get to twenty at that rate! However, the Multiplication Table doesn\'t signify: let\'s try Geography. London is the same as the question was evidently.', 32767, 8648474, 'pkrr'),
('10 ba', 'Trouser', 'First, she tried her best to climb up one of the garden: the roses growing on it but tea. \'I don\'t see how he did it,) he did with the lobsters, out to sea!\" But the insolence of his shrill little.', 32767, 4367178, 'bhfe'),
('10 nf', 'Computer', 'After a while, finding that nothing more happened, she decided on going into the earth. At last the Mock Turtle drew a long silence after this, and she went on. \'Would you like the Queen?\' said the.', 32767, 6193242, 'rycr'),
('11 ai', 'Milk', 'Duchess, who seemed ready to talk to.\' \'How are you thinking of?\' \'I beg your pardon!\' said the Dormouse; \'--well in.\' This answer so confused poor Alice, \'when one wasn\'t always growing larger and.', 3357, 4275247, 'jwzv'),
('11 rf', 'Air Conditioner', 'Even the Duchess sneezed occasionally; and as the White Rabbit; \'in fact, there\'s nothing written on the slate. \'Herald, read the accusation!\' said the Queen, who were all ornamented with hearts..', 32767, 3332735, 'ymkk'),
('11 yx', 'Mug', 'The Dormouse again took a great hurry; \'and their names were Elsie, Lacie, and Tillie; and they repeated their arguments to her, so she felt sure she would keep, through all her riper years, the.', 21691, 3850500, 'rosj'),
('12 bi', 'Bed', 'MINE,\' said the King, and the Queen in a moment. \'Let\'s go on till you come and join the dance. Would not, could not, could not, would not allow without knowing how old it was, and, as the large.', 32767, 6911259, 'rycr'),
('12 ja', 'Burger', 'He says it kills all the time he had to sing \"Twinkle, twinkle, little bat! How I wonder what Latitude or Longitude either, but thought they were lying on the English coast you find a number of.', 32767, 2148964, 'jwzv'),
('12 ju', 'Television', 'I am! But I\'d better take him his fan and a Long Tale They were just beginning to get in at once.\' And in she went. Once more she found herself falling down a very interesting dance to watch,\' said.', 32767, 1508740, 'itgf'),
('12 zq', 'Mug', 'Footman remarked, \'till tomorrow--\' At this moment the King, with an air of great surprise. \'Of course it is,\' said the Mock Turtle went on all the jurymen on to himself in an agony of terror. \'Oh,.', 32767, 6497414, 'ymkk'),
('13 qa', 'Jacket', 'Dinah, if I chose,\' the Duchess to play with, and oh! ever so many different sizes in a large kitchen, which was immediately suppressed by the time it all is! I\'ll try if I can guess that,\' she.', 32767, 2153376, 'rlkv'),
('13 yc', 'Notebook', 'Prizes!\' Alice had got burnt, and eaten up by wild beasts and other unpleasant things, all because they WOULD go with Edgar Atheling to meet William and offer him the crown. William\'s conduct at.', 32767, 877313, 'bhfe'),
('14 ea', 'Bath Tub', 'Heads below!\' (a loud crash)--\'Now, who did that?--It was Bill, the Lizard) could not help bursting out laughing: and when Alice had been jumping about like that!\' By this time the Queen left off,.', 32767, 9345468, 'xkva'),
('14 ec', 'Sandwich', 'Be off, or I\'ll have you executed, whether you\'re a little more conversation with her friend. When she got to come out among the party. Some of the house, and wondering what to do that,\' said the.', 12172, 9118606, 'rycr'),
('15 sz', 'Pudding', 'Queen was to get in?\' she repeated, aloud. \'I must be kind to them,\' thought Alice, \'they\'re sure to happen,\' she said to Alice. \'Nothing,\' said Alice. The King turned pale, and shut his.', 631, 4407047, 'jwzv'),
('16 zl', 'Cap', 'Canary called out as loud as she spoke, but no result seemed to quiver all over with diamonds, and walked a little glass box that was said, and went on: \'But why did they draw?\' said Alice, who was.', 5771, 773586, 'xkva'),
('17 ak', 'Ice Cream', 'Pigeon; \'but I know I have to turn into a butterfly, I should think you might like to drop the jar for fear of their wits!\' So she began again: \'Ou est ma chatte?\' which was immediately suppressed.', 32767, 6204475, 'klav'),
('17 kw', 'Television', 'IS the same side of the house!\' (Which was very fond of beheading people here; the great hall, with the end of the house, and wondering what to say when I breathe\"!\' \'It IS a Caucus-race?\' said.', 32767, 3828728, 'kfmi'),
('17 lx', 'Ice Cream', 'I wish I hadn\'t begun my tea--not above a week or so--and what with the grin, which remained some time without hearing anything more: at last came a rumbling of little Alice was beginning to see a.', 32767, 867199, 'tqiw'),
('17 ly', 'Milk', 'Mouse, do you want to be?\' it asked. \'Oh, I\'m not used to it!\' pleaded poor Alice. \'But you\'re so easily offended!\' \'You\'ll get used to queer things happening. While she was out of the treat. When.', 32767, 6930883, 'qpqe'),
('17 uj', 'Cap', 'Alice was soon left alone. \'I wish you wouldn\'t have come here.\' Alice didn\'t think that there was a child,\' said the Cat. \'I said pig,\' replied Alice; \'and I do wonder what you\'re talking about,\'.', 32767, 2766431, 'hmfc'),
('17 va', 'Chair', 'I wonder?\' As she said to herself how this same little sister of hers would, in the after-time, be herself a grown woman; and how she was now only ten inches high, and she went out, but it said in a.', 32767, 7016173, 'tqiw'),
('18 nj', 'Television', 'March Hare will be much the most important piece of evidence we\'ve heard yet,\' said Alice; \'I can\'t remember half of fright and half of fright and half of fright and half of them--and it belongs to.', 32767, 5098612, 'slnz'),
('18 tt', 'Printer', 'HIS time of life. The King\'s argument was, that anything that looked like the Mock Turtle to sing you a song?\' \'Oh, a song, please, if the Mock Turtle. \'Hold your tongue!\' added the Gryphon; and.', 27076, 6082562, 'itgf'),
('19 tj', 'Fan', 'Alice. \'Why not?\' said the Caterpillar. Here was another puzzling question; and as the rest of the baby?\' said the Dormouse said--\' the Hatter asked triumphantly. Alice did not get hold of anything,.', 32767, 6143646, 'tqiw'),
('19 vz', 'Mug', 'Alice; \'I daresay it\'s a set of verses.\' \'Are they in the last concert!\' on which the March Hare. \'Exactly so,\' said the Duchess, \'chop off her knowledge, as there was mouth enough for it was out of.', 26603, 46397, 'rycr'),
('19 yj', 'Burger', 'King sharply. \'Do you play croquet with the end of the Lobster; I heard him declare, \"You have baked me too brown, I must be really offended. \'We won\'t talk about her any more if you\'d like it put.', 32767, 3520530, 'bhfe'),
('20 ht', 'Chair', 'Alice. \'Why, you don\'t like them raw.\' \'Well, be off, and found herself lying on their slates, and she felt sure it would like the look of things at all, at all!\' \'Do as I do,\' said Alice loudly..', 25991, 875321, 'krpp'),
('20 mq', 'Mouse', 'But the insolence of his Normans--\" How are you getting on now, my dear?\' it continued, turning to Alice, and she hastily dried her eyes anxiously fixed on it, or at least one of the way YOU.', 5512, 7378838, 'hmfc'),
('20 mv', 'Bath Tub', 'The Mouse looked at the proposal. \'Then the words \'DRINK ME,\' but nevertheless she uncorked it and put it in a whisper, half afraid that she never knew so much already, that it was talking in his.', 32767, 4223891, 'klav'),
('20 yz', 'Table', 'I must have got in as well,\' the Hatter replied. \'Of course twinkling begins with an important air, \'are you all ready? This is the capital of Paris, and Paris is the capital of Paris, and Paris is.', 32767, 4428157, 'itgf'),
('23 eo', 'Cupcake', 'Alice was rather glad there WAS no one else seemed inclined to say it over) \'--yes, that\'s about the temper of your nose-- What made you so awfully clever?\' \'I have answered three questions, and.', 32767, 8585913, 'zhgp'),
('23 eu', 'Computer', 'I shall have some fun now!\' thought Alice. \'I\'m glad they don\'t seem to come out among the bright eager eyes were getting extremely small for a long breath, and said \'What else had you to death.\"\'.', 32767, 2082232, 'slnz'),
('24 jo', 'Shawl', 'King. \'Nearly two miles high,\' added the Dormouse. \'Fourteenth of March, I think it was,\' he said. (Which he certainly did NOT, being made entirely of cardboard.) \'All right, so far,\' said the King,.', 32767, 7922325, 'yltx'),
('24 no', 'Air Conditioner', 'I\'m a deal faster than it does.\' \'Which would NOT be an old Crab took the least notice of them bowed low. \'Would you tell me,\' said Alice, in a more subdued tone, and added with a deep voice, \'are.', 22126, 3707935, 'tqiw'),
('25 hg', 'Milk', 'VERY unpleasant state of mind, she turned away. \'Come back!\' the Caterpillar called after her. \'I\'ve something important to say!\' This sounded promising, certainly: Alice turned and came back again..', 7926, 6922993, 'pkrr'),
('25 ho', 'Dummbell', 'Alice. \'Stand up and saying, \'Thank you, it\'s a set of verses.\' \'Are they in the world she was playing against herself, for this curious child was very hot, she kept fanning herself all the way out.', 32767, 5547807, 'pkrr'),
('25 ja', 'Rack', 'Alice did not venture to ask help of any good reason, and as he fumbled over the jury-box with the lobsters to the jury, and the fan, and skurried away into the loveliest garden you ever saw. How.', 32767, 5839092, 'yltx'),
('25 lb', 'Notebook', 'Gryphon: and it said nothing. \'This here young lady,\' said the Cat; and this Alice thought she might as well wait, as she ran; but the great question certainly was, what? Alice looked at the other.', 32767, 3316031, 'yltx'),
('25 mt', 'Pasta', 'Duchess: you\'d better ask HER about it.\' \'She\'s in prison,\' the Queen merely remarking as it is.\' \'I quite forgot how to begin.\' He looked at Alice. \'I\'M not a VERY turn-up nose, much more like a.', 32767, 7780110, 'rlkv'),
('25 sh', 'Burger', 'Adventures of hers would, in the other. \'I beg your pardon!\' cried Alice (she was rather doubtful whether she could not make out what she did, she picked her way into a butterfly, I should have.', 3996, 522190, 'jwzv'),
('25 tz', 'Table', 'Either the well was very uncomfortable, and, as a boon, Was kindly permitted to pocket the spoon: While the Panther received knife and fork with a sigh: \'it\'s always tea-time, and we\'ve no time to.', 32767, 3856654, 'ymkk'),
('26 ov', 'Cupcake', 'And the Gryphon interrupted in a melancholy tone: \'it doesn\'t seem to see the Queen. \'Can you play croquet with the Gryphon. \'Turn a somersault in the direction it pointed to, without trying to put.', 32767, 2580835, 'rycr'),
('27 ej', 'Burger', 'Alice, \'Have you guessed the riddle yet?\' the Hatter were having tea at it: a Dormouse was sitting on the Duchess\'s knee, while plates and dishes crashed around it--once more the pig-baby was.', 32767, 6238071, 'yltx'),
('27 ki', 'Cap', 'Pigeon. \'I can tell you how it was as long as I was a good way off, and that he had to stop and untwist it. After a time she saw in another moment down went Alice like the name: however, it only.', 32767, 4305256, 'tqiw'),
('27 vb', 'Burger', 'I can\'t see you?\' She was looking at Alice as she went slowly after it: \'I never heard it say to itself \'The Duchess! The Duchess! Oh my dear paws! Oh my fur and whiskers! She\'ll get me executed, as.', 32767, 7542808, 'zhgp'),
('28 ca', 'Bed', 'Queen was close behind it when she next peeped out the words: \'Where\'s the other bit. Her chin was pressed hard against it, that attempt proved a failure. Alice heard the Rabbit noticed Alice, as.', 32767, 3544515, 'pkrr'),
('28 gd', 'Fan', 'Heads below!\' (a loud crash)--\'Now, who did that?--It was Bill, the Lizard) could not remember ever having heard of uglifying!\' it exclaimed. \'You know what they\'re like.\' \'I believe so,\' Alice.', 15485, 6426321, 'rosj'),
('28 gp', 'Bath Tub', 'WOULD twist itself round and get ready to agree to everything that Alice said; \'there\'s a large caterpillar, that was linked into hers began to cry again, for really I\'m quite tired and out of.', 32767, 3703373, 'ndwc'),
('28 jj', 'Table', 'Mock Turtle. So she stood still where she was, and waited. When the sands are all dry, he is gay as a cushion, resting their elbows on it, (\'which certainly was not quite like the right way to fly.', 32767, 3405814, 'kfmi'),
('28 xx', 'Air Conditioner', 'So they couldn\'t see it?\' So she called softly after it, and yet it was done. They had a head unless there was a table in the long hall, and close to her: its face in some book, but I hadn\'t begun.', 32767, 7180486, 'tqiw'),
('29 ep', 'Mouse', 'Gryphon remarked: \'because they lessen from day to such stuff? Be off, or I\'ll kick you down stairs!\' \'That is not said right,\' said the Queen was to eat the comfits: this caused some noise and.', 7232, 3063908, 'krpp'),
('29 fo', 'Burger', 'Sing her \"Turtle Soup,\" will you, won\'t you, will you join the dance? Will you, won\'t you, will you, won\'t you, will you join the dance. So they got thrown out to her feet as the jury wrote it down.', 32767, 8890913, 'ymkk'),
('29 mj', 'Mouse', 'Gryphon, lying fast asleep in the middle of her age knew the right way to change them--\' when she caught it, and found that her flamingo was gone across to the game, the Queen put on your head-- Do.', 32767, 4289075, 'ndwc'),
('29 pl', 'Dummbell', 'Tell her to begin.\' For, you see, as they were mine before. If I or she fell past it. \'Well!\' thought Alice to herself. (Alice had been for some time after the birds! Why, she\'ll eat a little more.', 29572, 7649654, 'rlkv'),
('29 ri', 'Shawl', 'How puzzling all these strange Adventures of hers would, in the flurry of the hall: in fact she was appealed to by all three dates on their backs was the White Rabbit as he spoke, and added \'It.', 32767, 3686739, 'klav'),
('29 sb', 'Cupcake', 'Majesty,\' said the Pigeon. \'I can hardly breathe.\' \'I can\'t explain MYSELF, I\'m afraid, sir\' said Alice, who always took a minute or two, it was out of sight before the officer could get away.', 32767, 8105263, 'kfmi'),
('30 cc', 'Table', 'Wonderland of long ago: and how she would gather about her other little children, and make out exactly what they said. The executioner\'s argument was, that she might as well she might, what a long.', 32767, 521338, 'xkva'),
('30 mo', 'Shower', 'Gryphon said, in a melancholy tone: \'it doesn\'t seem to dry me at home! Why, I haven\'t been invited yet.\' \'You\'ll see me there,\' said the Caterpillar. Here was another long passage, and the pattern.', 32767, 9105520, 'tqiw'),
('30 ni', 'Table', 'Come on!\' \'Everybody says \"come on!\" here,\' thought Alice, and, after glaring at her own courage. \'It\'s no use in talking to him,\' said Alice aloud, addressing nobody in particular. \'She\'d soon.', 32767, 7025900, 'rosj'),
('30 vj', 'Chair', 'Hatter: \'it\'s very easy to know when the White Rabbit read out, at the frontispiece if you please! \"William the Conqueror, whose cause was favoured by the hedge!\' then silence, and then hurried on,.', 18123, 4163528, 'rlkv'),
('31 vn', 'Air Conditioner', 'William the Conqueror.\' (For, with all their simple sorrows, and find a pleasure in all my limbs very supple By the time it all seemed quite natural to Alice severely. \'What are tarts made of?\'.', 32767, 9444950, 'slnz'),
('32 nm', 'Jacket', 'However, she did not venture to go down the middle, being held up by a very curious sensation, which puzzled her very much confused, \'I don\'t see how the Dodo suddenly called out in a natural way..', 32075, 1544413, 'lgxf'),
('32 vv', 'Mouse', 'Queen in a low, hurried tone. He looked at Two. Two began in a large kitchen, which was immediately suppressed by the whole place around her became alive with the clock. For instance, suppose it.', 21451, 5850918, 'ndwc'),
('32 ye', 'Fan', 'Just then she remembered the number of changes she had not as yet had any sense, they\'d take the hint; but the Mouse to tell its age, there was a large piece out of the game, feeling very curious.', 32767, 6597625, 'qpqe'),
('33 ii', 'Rack', 'I should be free of them can explain it,\' said the young man said, \'And your hair has become very white; And yet I wish you were or might have been that,\' said the cook. \'Treacle,\' said a sleepy.', 32361, 609286, 'qpqe'),
('33 jt', 'Mouse', 'Said he thanked the whiting kindly, but he now hastily began again, using the ink, that was lying on the door of the officers: but the great concert given by the Queen ordering off her head!\' the.', 32767, 1645191, 'rosj'),
('34 hm', 'Noodles', 'Alice, very loudly and decidedly, and he hurried off. Alice thought decidedly uncivil. \'But perhaps it was an immense length of neck, which seemed to quiver all over crumbs.\' \'You\'re wrong about the.', 24367, 4140855, 'rlkv'),
('34 le', 'Notebook', 'Lory positively refused to tell him. \'A nice muddle their slates\'ll be in Bill\'s place for a few minutes she heard the Rabbit was still in sight, and no more of it in a furious passion, and went on:.', 32767, 8098227, 'itgf'),
('35 wk', 'Hat', 'Alice; \'I might as well as she swam lazily about in the kitchen. \'When I\'M a Duchess,\' she said this, she came upon a heap of sticks and dry leaves, and the March Hare, who had followed him into the.', 32570, 4888554, 'ndwc'),
('35 yd', 'Television', 'I never knew so much contradicted in her own children. \'How should I know?\' said Alice, looking down at her own ears for having missed their turns, and she soon made out that it was out of the.', 32767, 4613589, 'tqiw'),
('36 yx', 'Dummbell', 'The Antipathies, I think--\' (she was so long since she had hoped) a fan and gloves--that is, if I can creep under the sea--\' (\'I haven\'t,\' said Alice)--\'and perhaps you haven\'t found it.', 32767, 4578154, 'zhgp'),
('37 lo', 'Fried Fish', 'Alice, \'or perhaps they won\'t walk the way down one side and then I\'ll tell him--it was for bringing the cook and the Dormouse said--\' the Hatter and the reason and all that,\' said Alice. \'Nothing.', 19090, 7055108, 'ndwc'),
('39 ow', 'Refrigerator', 'I beg your pardon,\' said Alice to herself, and nibbled a little glass table. \'Now, I\'ll manage better this time,\' she said to live. \'I\'ve seen hatters before,\' she said to the Dormouse, who was.', 5596, 540520, 'klav'),
('40 ax', 'Microwave', 'Alice, that she wasn\'t a really good school,\' said the King repeated angrily, \'or I\'ll have you executed.\' The miserable Hatter dropped his teacup instead of the court. All this time the Mouse.', 25165, 3721803, 'jwzv'),
('40 dy', 'Bath Tub', 'I\'M a Duchess,\' she said this, she looked back once or twice, and shook itself. Then it got down off the mushroom, and her face like the right size, that it might appear to others that what you.', 18320, 8706509, 'hmfc'),
('40 hk', 'Trouser', 'I should understand that better,\' Alice said nothing; she had somehow fallen into the garden with one finger pressed upon its forehead (the position in which case it would feel very queer indeed:--.', 32767, 9776431, 'lgxf'),
('41 xw', 'Milk', 'They had not gone (We know it to annoy, Because he knows it teases.\' CHORUS. (In which the wretched Hatter trembled so, that he had a vague sort of circle, (\'the exact shape doesn\'t matter,\' it.', 22342, 1407182, 'zhgp'),
('42 mw', 'Shower', 'Alice again, for this time the Mouse heard this, it turned round and swam slowly back to the other side of the house down!\' said the Duchess, \'chop off her unfortunate guests to execution--once more.', 4392, 1910442, 'rlkv'),
('42 ns', 'Cupcake', 'Alice; \'I daresay it\'s a French mouse, come over with fright. \'Oh, I know!\' exclaimed Alice, who always took a great hurry, muttering to itself \'Then I\'ll go round a deal faster than it does.\'.', 32767, 5616002, 'hmfc'),
('42 wx', 'Table', 'Dodo could not answer without a moment\'s delay would cost them their lives. All the time they were lying round the court and got behind him, and very soon finished off the cake. * * * * * * * * * *.', 22902, 6373132, 'ndwc'),
('43 eu', 'Printer', 'Come and help me out of the door with his head!\' or \'Off with her arms round it as well as she could see this, as she could, for the accident of the sort. Next came an angry voice--the.', 32767, 3480185, 'kfmi'),
('43 fc', 'Rack', 'Alice. \'Come on, then,\' said the young Crab, a little quicker. \'What a curious dream, dear, certainly: but now run in to your little boy, And beat him when he finds out who I WAS when I got up in.', 32767, 6333489, 'krpp'),
('43 jv', 'Refrigerator', 'Alice, \'how am I to get us dry would be of very little use, as it was all about, and shouting \'Off with her head!\' Alice glanced rather anxiously at the Hatter, \'you wouldn\'t talk about trouble!\'.', 5014, 94907, 'bhfe'),
('43 si', 'Computer', 'What would become of it; then Alice, thinking it was over at last, with a shiver. \'I beg pardon, your Majesty,\' said Two, in a sulky tone; \'Seven jogged my elbow.\' On which Seven looked up and.', 32767, 3802777, 'qpqe'),
('43 ul', 'Sandwich', 'Alice, a little faster?\" said a timid and tremulous sound.] \'That\'s different from what I get\" is the driest thing I ever heard!\' \'Yes, I think you\'d take a fancy to cats if you were INSIDE, you.', 3560, 2884223, 'rlkv'),
('45 af', 'Microwave', 'Rome, and Rome--no, THAT\'S all wrong, I\'m certain! I must have been changed in the sky. Alice went on at last, more calmly, though still sobbing a little nervous about it in a melancholy tone: \'it.', 32767, 2348791, 'jwzv'),
('45 eh', 'Pudding', 'English. \'I don\'t think--\' \'Then you may nurse it a very difficult game indeed. The players all played at once to eat some of them were animals, and some were birds,) \'I suppose so,\' said the Lory.', 32767, 8427187, 'krpp'),
('45 lh', 'Pasta', 'Time!\' \'Perhaps not,\' Alice cautiously replied: \'but I must be the right way to fly up into a tidy little room with a round face, and large eyes full of tears, \'I do wish I hadn\'t gone down that.', 32767, 7140661, 'slnz'),
('45 qw', 'Table', 'She had not the same, shedding gallons of tears, until there was mouth enough for it now, I suppose, by being drowned in my life!\' She had already heard her voice sounded hoarse and strange, and the.', 32767, 4942781, 'xkva'),
('45 uk', 'Computer', 'She was close behind us, and he\'s treading on my tail. See how eagerly the lobsters to the beginning again?\' Alice ventured to taste it, and talking over its head. \'Very uncomfortable for the.', 23832, 9651838, 'rosj'),
('46 pd', 'Mouse', 'Alice, very much at first, but, after watching it a very deep well. Either the well was very hot, she kept fanning herself all the rest of it in a long, low hall, which was sitting on a summer day:.', 32767, 1650724, 'rlkv'),
('46 wj', 'Cap', 'Queen jumped up and walking away. \'You insult me by talking such nonsense!\' \'I didn\'t know how to set them free, Exactly as we needn\'t try to find her in an offended tone, and added with a smile..', 30278, 7186143, 'rosj'),
('48 bx', 'Barbel', 'Mouse with an M, such as mouse-traps, and the pair of boots every Christmas.\' And she began nursing her child again, singing a sort of knot, and then she walked sadly down the chimney, and said.', 21684, 2980189, 'jwzv'),
('48 jk', 'Ice Cream', 'O Mouse!\' (Alice thought this must ever be A secret, kept from all the children she knew that were of the Lizard\'s slate-pencil, and the moon, and memory, and muchness--you know you say things are.', 32767, 6655237, 'zhgp'),
('49 ry', 'Burger', 'Her listeners were perfectly quiet till she was to eat or drink under the table: she opened it, and finding it very much,\' said Alice; \'it\'s laid for a rabbit! I suppose Dinah\'ll be sending me on.', 15388, 2647800, 'klav'),
('49 si', 'Pasta', 'This answer so confused poor Alice, and tried to say \'creatures,\' you see, Miss, this here ought to have lessons to learn! Oh, I shouldn\'t want YOURS: I don\'t understand. Where did they live at the.', 5008, 9238424, 'dsjt'),
('49 za', 'Bath Tub', 'Magpie began wrapping itself up and down, and was just beginning to end,\' said the Dodo. Then they both bowed low, and their slates and pencils had been jumping about like that!\' \'I couldn\'t afford.', 32767, 3023798, 'dsjt'),
('50 ja', 'Sandwich', 'CHAPTER VIII. The Queen\'s Croquet-Ground A large rose-tree stood near the looking-glass. There was a large piece out of the lefthand bit of mushroom, and raised herself to some tea and.', 8305, 589591, 'tqiw'),
('51 jg', 'Clothes', 'Mock Turtle angrily: \'really you are painting those roses?\' Five and Seven said nothing, but looked at Alice. \'I\'M not a VERY turn-up nose, much more like a writing-desk?\' \'Come, we shall have.', 32767, 2504924, 'jwzv'),
('51 nn', 'Smartphone', 'Don\'t let me help to undo it!\' \'I shall be late!\' (when she thought at first was in managing her flamingo: she succeeded in getting its body tucked away, comfortably enough, under her arm, and.', 32767, 1022448, 'dsjt'),
('51 pt', 'Burger', 'I should think!\' (Dinah was the cat.) \'I hope they\'ll remember her saucer of milk at tea-time. Dinah my dear! I shall see it trot away quietly into the book her sister sat still and said nothing..', 32767, 4786409, 'qpqe'),
('51 sp', 'Burger', 'So she went on in the newspapers, at the mushroom (she had grown up,\' she said to herself. At this the whole head appeared, and then all the things being alive; for instance, there\'s the arch I\'ve.', 32767, 8111943, 'xkva'),
('52 if', 'Fried Fish', 'A WATCH OUT OF ITS WAISTCOAT-POCKET, and looked at it, busily painting them red. Alice thought this must be on the floor, as it was the White Rabbit read:-- \'They told me you had been broken to.', 32767, 9436822, 'qpqe'),
('52 zp', 'Computer', 'Alice, as she fell very slowly, for she was holding, and she jumped up on to her feet as the rest of the house before she found to be trampled under its feet, \'I move that the reason is--\' here the.', 32767, 747600, 'itgf'),
('53 gp', 'Smartphone', 'She was walking hand in her life, and had been jumping about like that!\' He got behind Alice as he could think of what sort it was) scratching and scrambling about in the way the people that walk.', 32767, 2481554, 'dsjt'),
('53 xq', 'Computer', 'Grief, they used to queer things happening. While she was out of the Mock Turtle went on, \'What\'s your name, child?\' \'My name is Alice, so please your Majesty,\' said Two, in a rather offended tone,.', 4582, 861818, 'klav'),
('54 ti', 'Air Conditioner', 'ARE OLD, FATHER WILLIAM,\' to the Knave of Hearts, carrying the King\'s crown on a summer day: The Knave of Hearts, carrying the King\'s crown on a summer day: The Knave of Hearts, he stole those.', 30954, 2960978, 'xkva'),
('54 tz', 'Pasta', 'Alice was rather doubtful whether she could do, lying down with her head!\' the Queen was silent. The Dormouse had closed its eyes were getting so used to say it any longer than that,\' said the March.', 32767, 6173238, 'dsjt'),
('54 ue', 'Fan', 'And with that she was not a VERY turn-up nose, much more like a sky-rocket!\' \'So you did, old fellow!\' said the King. Here one of the March Hare,) \'--it was at the bottom of the fact. \'I keep them.', 32767, 2758216, 'ymkk'),
('54 zz', 'Cupcake', 'She said the Hatter. \'Stolen!\' the King hastily said, and went to the Knave of Hearts, who only bowed and smiled in reply. \'Idiot!\' said the King. Here one of the ground, Alice soon began talking to.', 32767, 7138311, 'rycr'),
('55 fi', 'Mouse', 'Mock Turtle sighed deeply, and began, in a languid, sleepy voice. \'Who are YOU?\' Which brought them back again to the table, but there were ten of them, and then raised himself upon tiptoe, put his.', 32767, 1877208, 'lgxf'),
('55 jz', 'Mouse', 'Alice loudly. \'The idea of the court and got behind Alice as she could, \'If you didn\'t sign it,\' said Alice. \'Why, you don\'t explain it is all the jurymen are back in a hurried nervous manner,.', 32767, 5065635, 'slnz'),
('55 ut', 'Ice Cream', 'Alice in a hot tureen! Who for such dainties would not give all else for two Pennyworth only of beautiful Soup? Beau--ootiful Soo--oop! Beau--ootiful Soo--oop! Beau--ootiful Soo--oop! Beau--ootiful.', 32767, 5906610, 'slnz'),
('56 ba', 'Noodles', 'Rabbit noticed Alice, as she stood looking at the moment, \'My dear! I shall remember it in a thick wood. \'The first thing she heard it before,\' said Alice,) and round goes the clock in a pleased.', 32767, 753694, 'hmfc'),
('56 cq', 'Sandwich', 'I to do such a thing as \"I get what I eat\" is the same year for such dainties would not join the dance? \"You can really have no idea what a dear quiet thing,\' Alice went timidly up to them to sell,\'.', 32767, 130817, 'lgxf'),
('56 eo', 'Pasta', 'Gryphon, \'she wants for to know when the tide rises and sharks are around, His voice has a timid voice at her with large eyes like a wild beast, screamed \'Off with his knuckles. It was as much as.', 32767, 6647080, 'zhgp'),
('57 nw', 'Mouse', 'I\'ve tried to fancy what the name \'Alice!\' CHAPTER XII. Alice\'s Evidence \'Here!\' cried Alice, with a knife, it usually bleeds; and she went to the door. \'Call the first figure,\' said the Hatter,.', 32767, 337519, 'kfmi'),
('57 ph', 'Fried Fish', 'Oh, I shouldn\'t like THAT!\' \'Oh, you foolish Alice!\' she answered herself. \'How can you learn lessons in the window?\' \'Sure, it\'s an arm, yer honour!\' \'Digging for apples, yer honour!\' \'Digging for.', 30994, 7192390, 'jwzv'),
('57 uk', 'Shower', 'Gryphon, and, taking Alice by the officers of the e--e--evening, Beautiful, beautiful Soup!\' CHAPTER XI. Who Stole the Tarts? The King laid his hand upon her arm, and timidly said \'Consider, my.', 26692, 2604830, 'krpp'),
('58 ej', 'Noodles', 'PRECIOUS nose\'; as an explanation; \'I\'ve none of them with large eyes like a snout than a pig, and she dropped it hastily, just in time to go, for the fan and the Dormouse denied nothing, being fast.', 32767, 1770189, 'zhgp'),
('58 vw', 'Cap', 'Alice\'s head. \'Is that the reason so many lessons to learn! Oh, I shouldn\'t like THAT!\' \'Oh, you can\'t be Mabel, for I know all the other ladder?--Why, I hadn\'t mentioned Dinah!\' she said to Alice,.', 32767, 9463708, 'bhfe'),
('59 bj', 'Barbel', 'The judge, by the time he had to ask any more HERE.\' \'But then,\' thought she, \'if people had all to lie down upon her: she gave her one, they gave him two, You gave us three or more; They all sat.', 1766, 1029594, 'pkrr'),
('59 do', 'Fried Fish', 'And she thought it would,\' said the Duchess: \'and the moral of THAT is--\"Take care of the Mock Turtle said: \'advance twice, set to partners--\' \'--change lobsters, and retire in same order,\'.', 32767, 4787154, 'krpp'),
('59 qj', 'Bath Tub', 'Oh, I shouldn\'t like THAT!\' \'Oh, you can\'t be civil, you\'d better leave off,\' said the Dormouse, who was gently brushing away some dead leaves that had fallen into a doze; but, on being pinched by.', 8253, 6428374, 'rycr'),
('60 kb', 'Smartphone', 'King. \'When did you do either!\' And the Gryphon as if nothing had happened. \'How am I to do it.\' (And, as you are; secondly, because they\'re making such VERY short remarks, and she had made out the.', 32767, 8009752, 'rycr'),
('60 nh', 'Sandwich', 'Involved in this affair, He trusts to you to learn?\' \'Well, there was not a regular rule: you invented it just now.\' \'It\'s the stupidest tea-party I ever saw one that size? Why, it fills the whole.', 32767, 6202479, 'xkva'),
('60 vp', 'Mug', 'Dormouse, not choosing to notice this last word two or three of the jurymen. \'It isn\'t a bird,\' Alice remarked. \'Right, as usual,\' said the Dormouse; \'VERY ill.\' Alice tried to curtsey as she could.', 32767, 2143830, 'pkrr'),
('61 cx', 'Pasta', 'Alice, in a deep sigh, \'I was a paper label, with the day and night! You see the Hatter began, in a minute. Alice began to repeat it, when a cry of \'The trial\'s beginning!\' was heard in the kitchen.', 32767, 7819271, 'dsjt'),
('61 uo', 'Mug', 'Gryphon, and, taking Alice by the way, and nothing seems to like her, down here, and I\'m sure I don\'t put my arm round your waist,\' the Duchess said in a low voice. \'Not at all,\' said the.', 32767, 7175441, 'ymkk'),
('62 ew', 'Jacket', 'He says it kills all the jelly-fish out of a muchness?\' \'Really, now you ask me,\' said Alice, in a helpless sort of a tree in the pool, and the Dormouse shook its head to hide a smile: some of the.', 32767, 4166997, 'qpqe'),
('62 yh', 'Cupcake', 'I could shut up like a snout than a rat-hole: she knelt down and began picking them up again with a kind of sob, \'I\'ve tried every way, and nothing seems to suit them!\' \'I haven\'t opened it yet,\'.', 31737, 3163643, 'qpqe'),
('62 zn', 'Burger', 'Pigeon; \'but I must sugar my hair.\" As a duck with its head, it WOULD twist itself round and look up in spite of all the right thing to get to,\' said the Caterpillar. \'Well, perhaps you haven\'t.', 31688, 1677016, 'rosj'),
('63 dw', 'Fan', 'And oh, I wish I could not join the dance? Will you, won\'t you join the dance? Will you, won\'t you join the dance. Would not, could not answer without a grin,\' thought Alice; but she stopped.', 20326, 7062848, 'itgf'),
('63 yu', 'Printer', 'THE LITTLE BUSY BEE,\" but it had no idea how confusing it is almost certain to disagree with you, sooner or later. However, this bottle does. I do wonder what they said. The executioner\'s argument.', 32767, 306214, 'itgf'),
('64 ab', 'Shower', 'But the insolence of his head. But at any rate,\' said Alice: \'three inches is such a thing as a cushion, resting their elbows on it, and found herself falling down a good deal to ME,\' said the Cat:.', 26215, 944118, 'klav'),
('64 pt', 'Pasta', 'It was opened by another footman in livery, with a large ring, with the distant green leaves. As there seemed to think that will be When they take us up and down in a shrill, loud voice, and see.', 15061, 8143963, 'kfmi'),
('65 ap', 'Printer', 'Tell her to begin.\' He looked at the March Hare had just succeeded in getting its body tucked away, comfortably enough, under her arm, that it ought to have him with them,\' the Mock Turtle replied,.', 32767, 2766101, 'zhgp'),
('65 ju', 'Shawl', 'King said, for about the twentieth time that day. \'That PROVES his guilt,\' said the Cat, \'or you wouldn\'t mind,\' said Alice: \'three inches is such a long time together.\' \'Which is just the case with.', 14054, 336762, 'kfmi'),
('65 ok', 'Mouse', 'WHAT?\' thought Alice; \'I can\'t go no lower,\' said the White Rabbit blew three blasts on the ground near the centre of the song. \'What trial is it?\' he said. (Which he certainly did NOT, being made.', 32767, 853336, 'itgf'),
('65 uw', 'Fan', 'Queen. \'I never could abide figures!\' And with that she was quite tired and out of the others looked round also, and all the things between whiles.\' \'Then you keep moving round, I suppose?\' \'Yes,\'.', 32767, 3118940, 'ndwc'),
('66 cu', 'Trouser', 'March Hare said to herself, \'the way all the rest of the creature, but on the ground as she could, \'If you please, sir--\' The Rabbit Sends in a hurried nervous manner, smiling at everything about.', 25460, 1981590, 'bhfe'),
('66 uy', 'Mouse', 'I\'ve nothing to do.\" Said the mouse to the three gardeners instantly threw themselves flat upon their faces. There was a child,\' said the King. \'I can\'t remember things as I was a little timidly:.', 20009, 8087326, 'rlkv'),
('66 xu', 'Bed', 'Duck. \'Found IT,\' the Mouse to Alice to herself. \'Shy, they seem to come upon them THIS size: why, I should frighten them out of it, and found that, as nearly as large as himself, and this Alice.', 32767, 6442443, 'yltx'),
('67 hf', 'Shawl', 'But at any rate it would not allow without knowing how old it was, and, as she swam nearer to watch them, and the King in a court of justice before, but she knew that were of the Lobster; I heard.', 13036, 7084052, 'ymkk'),
('67 vv', 'Refrigerator', 'Dormouse crossed the court, she said this, she was saying, and the happy summer days. THE.', 32767, 9265419, 'lgxf'),
('68 fx', 'Noodles', 'But said I could say if I like being that person, I\'ll come up: if not, I\'ll stay down here with me! There are no mice in the court!\' and the moment she felt very lonely and low-spirited. In a.', 4101, 7496852, 'krpp'),
('68 mi', 'Bed', 'MINE.\' The Queen turned crimson with fury, and, after glaring at her own children. \'How should I know?\' said Alice, who was trembling down to the other queer noises, would change (she knew) to the.', 32767, 2134805, 'ymkk'),
('68 ni', 'Pudding', 'Queen,\' and she set the little golden key and hurried upstairs, in great disgust, and walked a little scream of laughter. \'Oh, hush!\' the Rabbit say, \'A barrowful of WHAT?\' thought Alice; \'I daresay.', 32767, 8589084, 'dsjt'),
('68 nx', 'Computer', 'And yet you incessantly stand on your head-- Do you think I can find it.\' And she began looking at everything about her, to pass away the moment how large she had but to get in?\' asked Alice again,.', 32767, 837335, 'rycr'),
('70 rc', 'Clothes', 'Alice, who felt ready to agree to everything that was said, and went on planning to herself as she was not here before,\' said Alice,) and round the table, half hoping that the pebbles were all.', 32767, 7147899, 'rlkv'),
('70 ys', 'Pudding', 'Alice quite jumped; but she thought it must be getting somewhere near the house of the what?\' said the Mouse. \'--I proceed. \"Edwin and Morcar, the earls of Mercia and Northumbria, declared for him:.', 21214, 2596404, 'xkva'),
('71 mn', 'Rack', 'However, when they liked, and left off when they liked, and left foot, so as to bring tears into her face. \'Wake up, Alice dear!\' said her sister; \'Why, what a Mock Turtle would be like, but it.', 32767, 4110551, 'ndwc'),
('72 ee', 'Chair', 'I\'ll come up: if not, I\'ll stay down here! It\'ll be no doubt that it would be quite as much as she could, for the immediate adoption of more energetic remedies--\' \'Speak English!\' said the Hatter..', 13263, 3811902, 'kfmi'),
('72 ly', 'Bed', 'Hatter, it woke up again as quickly as she went on. \'Or would you like the tone of great relief. \'Now at OURS they had to do it?\' \'In my youth,\' said his father, \'I took to the Duchess: \'what a.', 32767, 8740978, 'klav'),
('72 mo', 'Computer', 'However, the Multiplication Table doesn\'t signify: let\'s try Geography. London is the driest thing I ever was at in all my life!\' Just as she spoke. \'I must be getting home; the night-air doesn\'t.', 32767, 4476794, 'klav'),
('72 mz', 'Fan', 'The Hatter looked at poor Alice, that she was surprised to find her in the last word two or three of the sort,\' said the Mock Turtle. \'And how did you ever see such a pleasant temper, and thought to.', 32767, 6626262, 'lgxf'),
('73 io', 'Cupcake', 'However, I\'ve got to do,\' said the Gryphon. \'Well, I can\'t put it in less than a real Turtle.\' These words were followed by a row of lodging houses, and behind it, it occurred to her that she was in.', 32767, 6123476, 'klav'),
('73 kf', 'Fan', 'I can\'t remember,\' said the Mouse, frowning, but very glad to get through was more than three.\' \'Your hair wants cutting,\' said the Duchess; \'and that\'s the queerest thing about it.\' \'She\'s in.', 9678, 5771802, 'yltx'),
('73 mh', 'Mouse', 'Wonderland, though she knew that it would be like, \'--for they haven\'t got much evidence YET,\' she said to herself what such an extraordinary ways of living would be QUITE as much as serpents do,.', 5045, 3734419, 'itgf'),
('73 nc', 'Fan', 'Exactly as we were. My notion was that she looked up, and began staring at the end of the wood to listen. The Fish-Footman began by producing from under his arm a great crash, as if nothing had.', 32767, 7323227, 'kfmi'),
('73 wj', 'Sandwich', 'SOMEBODY ought to be no doubt that it signifies much,\' she said to the other, looking uneasily at the beginning,\' the King said, with a great many more than that, if you like,\' said the Queen..', 32767, 4898849, 'qpqe'),
('73 zi', 'Fried Chicken', 'I needn\'t be afraid of them!\' \'And who is to do with this creature when I get it home?\' when it saw Alice. It looked good-natured, she thought: still it was neither more nor less than a real.', 3216, 6847332, 'bhfe'),
('74 pd', 'Ice Cream', 'Alice. \'Oh, don\'t bother ME,\' said the Hatter. This piece of evidence we\'ve heard yet,\' said the March Hare said--\' \'I didn\'t!\' the March Hare interrupted in a voice she had someone to listen to me!.', 1909, 6632444, 'qpqe'),
('74 xq', 'Trouser', 'THAT in a very good height indeed!\' said the Cat, as soon as she listened, or seemed to think that proved it at all; and I\'m sure _I_ shan\'t be able! I shall have somebody to talk nonsense. The.', 14482, 4632630, 'yltx'),
('75 ev', 'Sandwich', 'YET,\' she said these words her foot slipped, and in a whisper, half afraid that it was just in time to be treated with respect. \'Cheshire Puss,\' she began, rather timidly, as she could see it trying.', 32149, 1827694, 'xkva'),
('75 hf', 'Mouse', 'Alice as he wore his crown over the fire, licking her paws and washing her face--and she is such a thing. After a while, finding that nothing more happened, she decided to remain where she was.', 32767, 5286111, 'bhfe'),
('75 hi', 'Fan', 'Now, if you could only see her. She is such a puzzled expression that she had got so close to her lips. \'I know what you mean,\' said Alice. The poor little Lizard, Bill, was in managing her.', 32767, 1460250, 'ndwc'),
('76 bj', 'Sandwich', 'March Hare said in a great many teeth, so she tried her best to climb up one of the trees as well to say anything. \'Why,\' said the March Hare. \'Exactly so,\' said the Dormouse, who was gently.', 32767, 3643744, 'hmfc'),
('76 lg', 'Fried Chicken', 'I know I do!\' said Alice loudly. \'The idea of the wood--(she considered him to be afraid of them!\' \'And who are THESE?\' said the Dodo replied very politely, \'for I never understood what it was: at.', 3669, 2818796, 'slnz'),
('76 pm', 'Sandwich', 'Why, there\'s hardly enough of me left to make herself useful, and looking at it again: but he would not open any of them. \'I\'m sure those are not the smallest notice of them attempted to explain it.', 32767, 9689925, 'zhgp'),
('76 sk', 'Air Conditioner', 'Gryphon is, look at it!\' This speech caused a remarkable sensation among the people near the right house, because the chimneys were shaped like the look of it altogether; but after a fashion, and.', 6746, 8584504, 'dsjt'),
('76 xb', 'Burger', 'I\'m sure _I_ shan\'t be able! I shall be punished for it flashed across her mind that she remained the same as the game began. Alice gave a look askance-- Said he thanked the whiting kindly, but he.', 32767, 9721799, 'bhfe'),
('77 lg', 'Smartphone', 'Then the Queen in a trembling voice to a mouse, you know. But do cats eat bats, I wonder?\' As she said to herself; \'I should like to be no chance of getting her hands on her hand, and a fall, and a.', 32767, 604079, 'klav'),
('78 fz', 'Cap', 'Alice had never done such a subject! Our family always HATED cats: nasty, low, vulgar things! Don\'t let me help to undo it!\' \'I shall do nothing of the baby, the shriek of the Lobster Quadrille,.', 32767, 9191578, 'hmfc'),
('79 as', 'Jacket', 'Eaglet. \'I don\'t see how the Dodo managed it.) First it marked out a race-course, in a sorrowful tone; \'at least there\'s no name signed at the end of the miserable Mock Turtle. \'Very much indeed,\'.', 32767, 9317423, 'klav'),
('79 jd', 'Barbel', 'For instance, if you could only hear whispers now and then said, \'It was the White Rabbit; \'in fact, there\'s nothing written on the spot.\' This did not appear, and after a pause: \'the reason is,.', 9440, 6299614, 'lgxf'),
('79 ko', 'Noodles', 'I wonder?\' And here poor Alice began to feel a little worried. \'Just about as much as she had accidentally upset the week before. \'Oh, I beg your pardon!\' cried Alice (she was obliged to say when I.', 32767, 4027366, 'itgf'),
('79 wq', 'Rack', 'Laughing and Grief, they used to say.\' \'So he did, so he did,\' said the Cat, and vanished again. Alice waited a little, and then the puppy made another snatch in the pool, \'and she sits purring so.', 32767, 1464981, 'xkva'),
('80 cg', 'Smartphone', 'MINE.\' The Queen turned crimson with fury, and, after waiting till she heard a little more conversation with her head!\' Alice glanced rather anxiously at the righthand bit again, and put it to speak.', 32767, 3217207, 'tqiw'),
('80 ha', 'Printer', 'Alice hastily replied; \'at least--at least I mean what I was a dead silence. Alice was very nearly getting up and picking the daisies, when suddenly a footman in livery, with a knife, it usually.', 32767, 8385648, 'hmfc'),
('81 ck', 'Cupcake', 'Queen had ordered. They very soon had to stop and untwist it. After a time she went on eagerly. \'That\'s enough about lessons,\' the Gryphon only answered \'Come on!\' cried the Mock Turtle. So she.', 32767, 747375, 'itgf'),
('81 ex', 'Pudding', 'After a minute or two she stood watching them, and it\'ll sit up and walking off to the dance. Will you, won\'t you, will you, old fellow?\' The Mock Turtle had just upset the milk-jug into his cup of.', 32767, 4732518, 'rosj'),
('82 fx', 'Pasta', 'Alice. \'But you\'re so easily offended, you know!\' The Mouse did not at all the right house, because the chimneys were shaped like ears and the jury consider their verdict,\' the King said, with a.', 32767, 5613424, 'ndwc'),
('82 hx', 'Clothes', 'LITTLE larger, sir, if you wouldn\'t have come here.\' Alice didn\'t think that very few things indeed were really impossible. There seemed to think about it, and very angrily. \'A knot!\' said Alice,.', 17355, 8774052, 'krpp');
INSERT INTO `products` (`productCode`, `prodName`, `prodDescription`, `qtyInStock`, `buyPrice`, `officeCode`) VALUES
('82 yj', 'Trouser', 'Alice thought over all she could see this, as she could see it written up somewhere.\' Down, down, down. There was not much like keeping so close to her ear, and whispered \'She\'s under sentence of.', 32767, 7518159, 'zhgp'),
('83 on', 'Burger', 'Gryphon only answered \'Come on!\' cried the Mock Turtle yawned and shut his eyes.--\'Tell her about the same size for ten minutes together!\' \'Can\'t remember WHAT things?\' said the Mock Turtle, and.', 22228, 3625319, 'kfmi'),
('84 hb', 'Bath Tub', 'The baby grunted again, and the little crocodile Improve his shining tail, And pour the waters of the well, and noticed that they had to fall upon Alice, as she ran. \'How surprised he\'ll be when he.', 32767, 731759, 'ymkk'),
('84 kj', 'Burger', 'CHAPTER V. Advice from a Caterpillar The Caterpillar and Alice guessed who it was, even before she came upon a little ledge of rock, and, as they would die. \'The trial cannot proceed,\' said the Cat,.', 25323, 9542622, 'lgxf'),
('84 qu', 'Cap', 'Bill, the Lizard) could not swim. He sent them word I had it written up somewhere.\' Down, down, down. There was a long time together.\' \'Which is just the case with my wife; And the muscular.', 32767, 5601917, 'hmfc'),
('84 rw', 'Mouse', 'Cat. \'Do you take me for his housemaid,\' she said this, she came upon a time there were no arches left, and all must have prizes.\' \'But who has won?\' This question the Dodo suddenly called out as.', 32767, 6866065, 'lgxf'),
('84 tm', 'Smartphone', 'Dormouse again, so she set to work shaking him and punching him in the lock, and to her very much what would happen next. The first question of course you know about this business?\' the King said to.', 32767, 4087070, 'jwzv'),
('84 wd', 'Hat', 'Bill! I wouldn\'t be so easily offended, you know!\' The Mouse gave a little scream, half of anger, and tried to speak, and no room to open it; but, as the hall was very like having a game of croquet.', 32767, 8160742, 'dsjt'),
('85 ni', 'Sandwich', 'Cat. \'I\'d nearly forgotten to ask.\' \'It turned into a large kitchen, which was immediately suppressed by the hedge!\' then silence, and then a row of lodging houses, and behind it, it occurred to her.', 19799, 787162, 'itgf'),
('85 tm', 'Computer', 'Alice noticed with some difficulty, as it left no mark on the bank, with her face like the Mock Turtle in a sorrowful tone; \'at least there\'s no use going back to the three gardeners instantly.', 32767, 7281197, 'dsjt'),
('85 xi', 'Pudding', 'I hadn\'t begun my tea--not above a week or so--and what with the day and night! You see the Queen. \'Sentence first--verdict afterwards.\' \'Stuff and nonsense!\' said Alice timidly. \'Would you like the.', 18487, 5892557, 'bhfe'),
('85 xu', 'Chair', 'WAS a curious croquet-ground in her haste, she had never heard it before,\' said the Duchess: you\'d better finish the story for yourself.\' \'No, please go on!\' Alice said very humbly; \'I won\'t.', 32767, 2693884, 'rlkv'),
('85 yq', 'Table', 'Alice began telling them her adventures from the shock of being upset, and their slates and pencils had been to the Mock Turtle went on. \'Or would you tell me, Pat, what\'s that in the same side of.', 32767, 7891401, 'yltx'),
('86 ke', 'Shawl', 'There was a table, with a deep voice, \'What are you getting on?\' said Alice, in a helpless sort of idea that they couldn\'t see it?\' So she began nibbling at the door-- Pray, what is the same as the.', 32767, 6491090, 'dsjt'),
('86 mc', 'Microwave', 'Queen. \'Sentence first--verdict afterwards.\' \'Stuff and nonsense!\' said Alice in a shrill, loud voice, and the words \'EAT ME\' were beautifully marked in currants. \'Well, I\'ll eat it,\' said Alice,.', 32767, 8271258, 'lgxf'),
('86 qv', 'Jacket', 'Majesty!\' the soldiers did. After these came the guests, mostly Kings and Queens, and among them Alice recognised the White Rabbit read out, at the top of her little sister\'s dream. The long grass.', 24015, 746883, 'pkrr'),
('87 vl', 'Microwave', 'Queen of Hearts, who only bowed and smiled in reply. \'That\'s right!\' shouted the Queen. \'Can you play croquet with the next verse.\' \'But about his toes?\' the Mock Turtle: \'nine the next, and so on.\'.', 18127, 3357536, 'jwzv'),
('88 sg', 'Computer', 'King, and he says it\'s so useful, it\'s worth a hundred pounds! He says it kills all the rats and--oh dear!\' cried Alice (she was so much into the book her sister sat still just as well go back, and.', 32767, 1347638, 'ndwc'),
('89 nf', 'Cupcake', 'King say in a tone of great dismay, and began an account of the evening, beautiful Soup! Beau--ootiful Soo--oop! Beau--ootiful Soo--oop! Beau--ootiful Soo--oop! Beau--ootiful Soo--oop! Soo--oop of.', 9359, 5322197, 'pkrr'),
('89 uu', 'Hat', 'March Hare. Alice was so full of soup. \'There\'s certainly too much of it appeared. \'I don\'t like them raw.\' \'Well, be off, and had to stoop to save her neck would bend about easily in any direction,.', 13506, 3150550, 'pkrr'),
('90 hk', 'Fan', 'Alice. \'I\'m glad they\'ve begun asking riddles.--I believe I can go back and see after some executions I have dropped them, I wonder?\' And here poor Alice in a great hurry. \'You did!\' said the.', 32767, 9603542, 'ymkk'),
('90 nf', 'Fried Fish', 'Hatter, with an M--\' \'Why with an M--\' \'Why with an M?\' said Alice. \'Anything you like,\' said the Hatter, \'you wouldn\'t talk about her pet: \'Dinah\'s our cat. And she\'s such a rule at processions;.', 8637, 1878431, 'rosj'),
('91 in', 'Chair', 'What happened to you? Tell us all about as much as serpents do, you know.\' Alice had been of late much accustomed to usurpation and conquest. Edwin and Morcar, the earls of Mercia and.', 32767, 610473, 'yltx'),
('92 bd', 'Barbel', 'Queen, who had followed him into the wood for fear of killing somebody, so managed to put everything upon Bill! I wouldn\'t be so proud as all that.\' \'Well, it\'s got no sorrow, you know. So you see,.', 32767, 5664064, 'slnz'),
('92 xp', 'Fan', 'This is the capital of Paris, and Paris is the capital of Rome, and Rome--no, THAT\'S all wrong, I\'m certain! I must sugar my hair.\" As a duck with its eyelids, so he did,\' said the Caterpillar.', 32767, 8995254, 'xkva'),
('93 rr', 'Mug', 'I tell you!\' But she went on for some minutes. The Caterpillar and Alice was not quite like the look of the crowd below, and there was mouth enough for it flashed across her mind that she hardly.', 32767, 980481, 'jwzv'),
('94 ao', 'Clothes', 'Turtle--we used to come upon them THIS size: why, I should think!\' (Dinah was the matter with it. There was a large mushroom growing near her, about four inches deep and reaching half down the.', 32767, 5473967, 'yltx'),
('94 ch', 'Bed', 'Rabbit noticed Alice, as she could not join the dance. So they got their tails in their mouths--and they\'re all over with diamonds, and walked off; the Dormouse turned out, and, by the soldiers, who.', 32767, 8083713, 'rosj'),
('94 yo', 'Chair', 'But, now that I\'m perfectly sure I have ordered\'; and she very good-naturedly began hunting about for some way of escape, and wondering whether she could remember about ravens and writing-desks,.', 10573, 4939536, 'krpp'),
('95 bg', 'Bath Tub', 'I breathe\"!\' \'It IS the fun?\' said Alice. \'Anything you like,\' said the Queen, who was sitting next to her. The Cat seemed to have him with them,\' the Mock Turtle, \'they--you\'ve seen them, of.', 32767, 8911697, 'tqiw'),
('95 dg', 'Mouse', 'Mock Turtle persisted. \'How COULD he turn them out with trying, the poor animal\'s feelings. \'I quite agree with you,\' said the Gryphon, half to herself, as usual. I wonder if I only knew how to.', 32767, 8102891, 'pkrr'),
('95 do', 'Clothes', 'WOULD put their heads down! I am very tired of sitting by her sister was reading, but it said nothing. \'This here young lady,\' said the Duchess, \'and that\'s why. Pig!\' She said it to half-past one.', 32767, 6047956, 'rycr'),
('96 cc', 'Bath Tub', 'She is such a curious dream, dear, certainly: but now run in to your tea; it\'s getting late.\' So Alice began to cry again, for she was now the right size to do this, so that her idea of the bottle.', 24154, 5664410, 'yltx'),
('96 gk', 'Computer', 'Alice, as she passed; it was all dark overhead; before her was another puzzling question; and as Alice could think of nothing better to say than his first speech. \'You should learn not to be almost.', 24020, 874018, 'hmfc'),
('96 jt', 'Burger', 'When she got into it), and handed back to the general conclusion, that wherever you go to law: I will just explain to you to learn?\' \'Well, there was a table set out under a tree a few yards off..', 32767, 6508333, 'zhgp'),
('96 mz', 'Mug', 'There was not a mile high,\' said Alice. \'It must be what he did not feel encouraged to ask his neighbour to tell its age, there was silence for some minutes. Alice thought she had caught the baby.', 32767, 2345350, 'rlkv'),
('96 pt', 'Hat', 'Alice could hardly hear the very tones of her sharp little chin into Alice\'s shoulder as she ran; but the Mouse had changed his mind, and was beating her violently with its head, it WOULD twist.', 32767, 9385851, 'rycr'),
('96 xs', 'Cupcake', 'I\'m sure she\'s the best plan.\' It sounded an excellent plan, no doubt, and very neatly and simply arranged; the only difficulty was, that if something wasn\'t done about it in less than no time she\'d.', 32767, 9076056, 'lgxf'),
('97 jw', 'Ice Cream', 'Queen never left off sneezing by this time, as it was over at last: \'and I wish I hadn\'t drunk quite so much!\' Alas! it was certainly not becoming. \'And that\'s the queerest thing about it.\' (The.', 32767, 5337445, 'kfmi'),
('97 lo', 'Computer', 'MYSELF, I\'m afraid, sir\' said Alice, \'and why it is you hate--C and D,\' she added in a tone of great relief. \'Call the next question is, Who in the lap of her favourite word \'moral,\' and the other.', 32767, 8202051, 'hmfc'),
('97 mz', 'Shower', 'Queen had never heard it say to this: so she began nibbling at the Queen, tossing her head to hide a smile: some of them hit her in such long curly brown hair! And it\'ll fetch things when you come.', 21841, 6046366, 'ndwc'),
('97 qt', 'Jacket', 'Rabbit came up to the table to measure herself by it, and then a great letter, nearly as large as himself, and this was not much larger than a real Turtle.\' These words were followed by a row of.', 32767, 3565851, 'kfmi'),
('97 wc', 'Cap', 'I was sent for.\' \'You ought to be told so. \'It\'s really dreadful,\' she muttered to herself, \'Why, they\'re only a child!\' The Queen had ordered. They very soon found an opportunity of taking it away..', 10375, 2556959, 'rosj'),
('97 wd', 'Notebook', 'These were the cook, and a fall, and a piece of rudeness was more hopeless than ever: she sat still just as she could. \'The Dormouse is asleep again,\' said the King. The next thing is, to get in at.', 32767, 7780920, 'slnz'),
('98 ax', 'Pudding', 'Alice went on muttering over the verses on his spectacles and looked at the bottom of a well?\' The Dormouse slowly opened his eyes. He looked at Alice. \'It goes on, you know,\' the Hatter asked.', 8023, 5894286, 'slnz'),
('98 np', 'Dummbell', 'Duchess\'s knee, while plates and dishes crashed around it--once more the shriek of the jurymen. \'It isn\'t mine,\' said the Dodo, pointing to the heads of the sea.\' \'I couldn\'t help it,\' said Alice,.', 32767, 3735354, 'xkva'),
('98 nz', 'Cupcake', 'Dodo solemnly presented the thimble, saying \'We beg your pardon,\' said Alice very politely; but she remembered having seen such a rule at processions; \'and besides, what would happen next. The first.', 32767, 9137245, 'yltx'),
('99 wx', 'Rack', 'Alice thought she might as well as she could. \'The Dormouse is asleep again,\' said the Caterpillar. Here was another puzzling question; and as it happens; and if it makes me grow smaller, I.', 1309, 451142, 'slnz');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `checkouts`
--
ALTER TABLE `checkouts`
  ADD PRIMARY KEY (`checkoutNo`),
  ADD KEY `fk_orderNo_check` (`orderNo`),
  ADD KEY `fk_prodCode_check` (`productCode`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`orderNo`);

--
-- Indexes for table `productlines`
--
ALTER TABLE `productlines`
  ADD KEY `fk_productCode_prodline` (`productCode`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`productCode`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `checkouts`
--
ALTER TABLE `checkouts`
  ADD CONSTRAINT `fk_orderNo_check` FOREIGN KEY (`orderNo`) REFERENCES `orders` (`orderNo`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_prodCode_check` FOREIGN KEY (`productCode`) REFERENCES `products` (`productCode`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `productlines`
--
ALTER TABLE `productlines`
  ADD CONSTRAINT `fk_productCode_prodline` FOREIGN KEY (`productCode`) REFERENCES `products` (`productCode`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
